#include "H/KBscancodes.h"
#include "H/printf.h"
#include "H/IDT.h"
//#include "H/sound.h"
#include "mouse.cpp"
#include "H/Memory.h"
#include "H/Heap.h"
#include "H/Colors.h"
#include "H/typedefs.h"
#include "H/vga.h"
#include "H/Font.h"
#include "H/3D.h"
//#include "H/Time.h"
#define NULL = ((void*)0)

extern const char Text[];

extern "C" void _start(){
    //__BOOTSCREEN__();
    DeskColor(8);
    MainKeyboardHandler = Keyboardhandler;
    InitializeIDT();
    //initfont();
    //mouseinit();
    MemoryMapEntry** usableMemoryMaps = GetUsableMemoryRegions();
    // TODO:scanf, shell
    InitHeap(0x100000, 0x100000);
    //taskbar
    struct Window Taskbar = Window(0, 190, 360, 10, "");
    //double windowing test
    struct Window Test = Window(10, 25, 50, 100, "TEST");
    KBmouse.x = 160;
    KBmouse.y = 100;
    ctmouse(160, 100);
    //drawchar(1, 0, 0, 15);

    while(1)
    return;
}