#include "H/vga.h"

int windows = 0;
struct Window Windows[100];

bool SupportsMode(uint32 width, uint32 height, uint32 colordepth){
    return width == 320 && height == 200 && colordepth == 8;
}

char* GetFrameBufferSegment(){
    outb(0x3c0, 0x06);
    int segmentNumber = inb(0x3cf) & (3<<2);
    switch(segmentNumber){
        case 0<<2: return (char*)0x00000;
        case 1<<2: return (char*)0xA0000;
        case 2<<2: return (char*)0xB0000;
        case 3<<2: return (char*)0xB8000;
    }
}

void putPixel(uint32 x, uint32 y,  int colorIndex){
    char* pixel = (char*)0xA0000; //GetFrameBufferSegment();
    pixel[320*y+x] = colorIndex;
}

int getColorIndex(int r, int g, int b){
    if(r == 0x00, g == 0x00, b == 0xA8) return 1;
    if(r == 0x00, g == 0xA8, b == 0x00) return 2;
    if(r == 0xA8, g == 0x00, b == 0x00) return 3;
    if(r == 0x00, g == 0x00, b == 0x00) return 0;
    if(r == 0xA8, g == 0xA8, b == 0xA8) return 15;
    return 0x00;
}

void putPixel(uint32 x, uint32 y,  int r, int g, int b){
    putPixel(x,y, getColorIndex(r,g,b));
}

void Line(int x0, int y0, int x1, int y1, int color){
    int dx, dy, p, x, y;
 
	dx=x1-x0;
	dy=y1-y0;
 
	x=x0;
	y=y0;
 
	p=2*dy-dx;
 
	while(x<x1)
	{
		if(p>=0)
		{
			putPixel(x,y,color);
			y=y+1;
			p=p+2*dy-2*dx;
		}
		else
		{
			putPixel(x,y,color);
			p=p+2*dy;
		}
		x=x+1;
	}
}

void Rect(int locationX, int locationY, int sizeX, int sizeY, int color)
{
    char* vga = (char*)0xA0000;
    vga += locationX + (locationY * 320);
    for (int i = 0; i < sizeX; i++)
    {
        for (int a = 0; a < sizeY; a++)
        {
            vga[320*a+i] = color;
        }
    }
}

void Refresh(){

    DeskColor(GRAY);
    int n = 100;
    bool LC;
    int x;
    int y;

   for(uint64 i = 0; i < n; i++)
  {
      LC = KBmouse.mouseLeftClick;
      x = KBmouse.x;
      y = KBmouse.y;
      if (KBmouse.x >= Windows[i].left && Windows[i].right >= KBmouse.x && KBmouse.y >= Windows[i].top && Windows[i].bottom >= KBmouse.y && LC && KBmouse.mouseRight){
        Windows[i].left = Windows[i].left + 1;
      }else{
      if (KBmouse.x >= Windows[i].left && Windows[i].right >= KBmouse.x && KBmouse.y >= Windows[i].top && Windows[i].bottom >= KBmouse.y && LC && KBmouse.mouseLeft){
        Windows[i].left = Windows[i].left - 1;
      }else{
      if (KBmouse.x >= Windows[i].left && Windows[i].right >= KBmouse.x && KBmouse.y >= Windows[i].top && Windows[i].bottom >= KBmouse.y && LC && KBmouse.mouseUp){
        Windows[i].top = Windows[i].top - 1;
      }else{
      if (KBmouse.x >= Windows[i].left && Windows[i].right >= KBmouse.x && KBmouse.y >= Windows[i].top && Windows[i].bottom >= KBmouse.y && LC && KBmouse.mouseDown){
        Windows[i].top = Windows[i].top + 1;
      }}}}
      Rect(Windows[i].left, Windows[i].top, Windows[i].right, Windows[i].bottom, WHITE);
   }
}

struct Window Window(int x, int y, int xmax, int ymax, char* name){
    struct Window w;
    w.name = name;
    w.top = y;
    w.left = x;
    w.bottom = ymax;
    w.right = xmax;
    w.handle = name;
    windows = windows + 1;
    Windows[windows + 1] = w;
    return w;
}

void ctmouse(int x, int y){
    Refresh();
    if (KBmouse.mouseLeftClick)Rect(315, 0, 5, 5, RED);
    if (KBmouse.mouseRightClick)Rect(315, 0, 5, 5, BLUE);
    putPixel(x,y,BLACK);
    putPixel(x,y+1,BLACK);putPixel(x+1,y+1,BLACK);
    putPixel(x,y+2,BLACK);putPixel(x+1,y+2,RED);putPixel(x+2,y+2,BLACK);
    putPixel(x,y+3,BLACK);putPixel(x+1,y+3,RED);putPixel(x+2,y+3,RED);putPixel(x+3,y+3,BLACK);
    putPixel(x,y+4,BLACK);putPixel(x+1,y+4,RED);putPixel(x+2,y+4,BLACK);putPixel(x+3,y+4,BLACK);putPixel(x+4,y+4,BLACK);
    putPixel(x,y+5,BLACK);putPixel(x+1,y+5,RED);putPixel(x+2,y+5,BLACK);
    putPixel(x,y+6,BLACK);putPixel(x+1,y+6,BLACK);putPixel(x+2,y+6,BLACK);
                      
}

void DeskColor(int color){
    Rect(0,0,320,200,color);
}

void Triangle(int x1, int y1, int x2, int y2, int x3, int y3, char color){
    Line(x1, y1, x2, y2, color);
    Line(x2, y2, x3, y3, color);
    Line(x3, y3, x1, y1, color);
}

string font = LevFont;
int nullfunc(){
    return 0;
}
 
void drawchar(int c, int x, int y, int fgcolor){

    int xpos;
    int ypos;
    //void _assos['1'] = putPixel(xpos+x, ypos+y, fgcolor);
    //void _assos['0'] = nullfunc();
    //char chr = font[c[9*xpos+ypos]]
    for (xpos = 0; xpos <= 9; xpos++){
        for (ypos = 0; ypos <= 9; ypos++){
            //_assos[chr];
            //if (font[c[9*ypos+xpos]] == '1') putPixel(xpos+x, ypos+y, fgcolor);
        }
    }
}
