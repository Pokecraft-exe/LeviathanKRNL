#ifndef LFONT
#define LFONT
#include "typedefs.h"

extern string LevFont;
#endif