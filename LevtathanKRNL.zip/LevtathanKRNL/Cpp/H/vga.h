#pragma once
#include "IO.h"
#include "typedefs.h"
#include "Font.h"
#include "3D.h"
#include "math.h"
#include "IDT.h"
#define BLACK 0
#define WHITE 15
#define GREEN 2
#define BLUE 1
#define SKY 3
#define PURPLE 5
#define BROWN 6
#define LIGHT_GRAY 7
#define GRAY 8
#define LAPIS 9
#define LIME 10
#define CYAN 11
#define LIGHT_PURPLE 13
#define YELLOW 14
#define NULL_COLOR 16
#define NEW 16
#define RED 4

struct Window{
    char* name;
    int top;
    int left;
    int bottom;
    int right;
    char* handle;
};

void WriteRegisters(uint8* registers);
bool SupportsMode(uint32 width, uint32 height, uint32 colordepth);
bool SetMode(uint32 width, uint32 height, uint32 colordepth);
extern char * GetFrameBufferSegment();
void putPixel(uint32 x, uint32 y,  int colorIndex);
int getColorIndex(int r, int g, int b);
void putPixel(uint32 x, uint32 y,  int r, int g, int b);
void Line(int x0, int y0, int x1, int y1, int color);
void Triangle(int x1, int y1, int x2, int y2, int x3, int y3, int color);
void Rect(int locationX, int locationY, int sizeX, int sizeY, int color);
void Refresh();
Window Window(int y, int x, int ymax, int xmax, char* name);
void ctmouse(int x, int y);
void DeskColor(int color);
void drawchar(int c, int x, int y, int fgcolor);