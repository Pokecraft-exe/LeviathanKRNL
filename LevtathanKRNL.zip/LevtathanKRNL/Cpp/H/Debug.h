#include "typedefs.h"

extern string KERNEL_LOAD_ERROR = "Error cant load kernel\n";
extern string KERNEL_LOAD_SUCCESS = "load kernel\n";
extern string VGA_LOAD_ERROR = "Error cant load VGA\n";
extern string VGA_LOAD_SUCCESS = "load VGA\n";
extern string FRAMEBUFFER_LOAD_ERROR = "Error cant load framebuffer\n";
extern string FRAMEBUFFER_LOAD_SUCCESS = "load framebuffer\n";
extern string INTERRUPTS_LOAD_ERROR = "Error cant load interrupts\n";
extern string INTERRUPTS_LOAD_SUCCESS = "load kernel\n";
extern string KEYB_LOAD_ERROR = "Error cant load keyboard\n";
extern string KEYB_LOAD_SUCCESS = "load keyboard\n";
extern string MOUSE_LOAD_ERROR = "Error cant load mouse\n";
extern string KERNEL_LOAD_ERROR = "load mouse\n";