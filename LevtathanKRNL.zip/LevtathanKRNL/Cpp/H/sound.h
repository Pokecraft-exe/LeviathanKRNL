#pragma once
#include "typedefs.h"
#include "IO.h"
#include "IDT.h"

void PlaySound(uint32 nFrequence);
void noSound();
void beep();
void delay(int);