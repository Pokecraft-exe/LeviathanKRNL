#pragma once
#include "typedefs.h"
#include "vga.h"

void 2Drendering(x,y,sy,sy){
    window(x,y,sy,sy)
}