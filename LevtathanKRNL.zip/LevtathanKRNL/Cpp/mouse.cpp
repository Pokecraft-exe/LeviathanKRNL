#include "H/IO.h"
#include "H/typedefs.h"

/*void mouse_wait(unsigned char type)
{
  unsigned int _time_out=100000;
  if(type==0)
  {
    while(_time_out--) //Data
    {
      if((inb(0x64) & 1)==1)
      {
        return;
      }
    }
    return;
  }
  else
  {
    while(_time_out--) //Signal
    {
      if((inb(0x64) & 2)==0)
      {
        return;
      }
    }
    return;
  }
}
void mouse_write(unsigned char a_write)
{
 //Wait to be able to send a command
 mouse_wait(1);
 //Tell the mouse we are sending a command
 outb(0x64, 0xD4);
 //Wait for the final part
 mouse_wait(1);
 //Finally write
 outb(0x60, a_write);
}

unsigned char mouse_read()
{
 //Get response from mouse
 mouse_wait(0);
 return inb(0x60);
}

 void mouseinit()
{
    mouse_wait(1);
    outb(0x64,0xA8);
    mouse_wait(1);
    outb(0x64,0x20);
    unsigned char status_byte;
    mouse_wait(0);
    status_byte = (inb(0x60) | 2);
    mouse_wait(1);
    outb(0x64, 0x60);
    mouse_wait(1);
    outb(0x60, status_byte);
    mouse_write(0xF6);
    mouse_read();
    mouse_write(0xF4);
    mouse_read();
    //interruptHandlerRegister(12,&mouse_handler);
}

void mouse_updater()
{
  int mousedeltax=0,mousedeltay=0;
  int mouse_bytes[2];
  int cycle;
  while(1)
  {
    while(cycle<3)
      mouse_bytes[cycle++] = inb(0x60);
    //if (cycle == 3)
    {
      cycle = 0;
      if ((mouse_bytes[0] & 0x80) || (mouse_bytes[0] & 0x40))
        return;
      if (!(mouse_bytes[0] & 0x20))
        mousedeltay |= 0xFFFFFF00;
      if (!(mouse_bytes[0] & 0x10))
        mousedeltax |= 0xFFFFFF00;
     // if (mouse_bytes[0] & 0x4)
        //RectD(100,100,50,50,000,100,1000); //A Mouse button click
      //if (mouse_bytes[0] & 0x2)
        //RectD(100,100,100,50,1000,1000,1000); //Another Mouse Button Click
     // if (mouse_bytes[0] & 0x1)
        //RectD(100,100,50,100,1000,90,2000);  //Another Mouse Button Clicked
      /*if(mouse_bytes[1]>=1||mouse_bytes>=1)
          RectD(10,10,50,50,1000,1000,90);
      mousedeltax=mouse_bytes[1];
      mousedeltay=mouse_bytes[2];
      ctmouse(mousedeltax, mousedeltay);
    }
    asm volatile("int $50");
  }
}*/