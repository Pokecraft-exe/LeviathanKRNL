#include "H/errors.h"

__attribute__((interrupt)) void isr0(interrupt_frame* frame) {print("div by 0");while(1);};
__attribute__((interrupt)) void isr1(interrupt_frame* frame) {print("debug");while(1);};
__attribute__((interrupt)) void isr2(interrupt_frame* frame) {print("NMI");while(1);};
__attribute__((interrupt)) void isr3(interrupt_frame* frame) {print("breakpoint");while(1);};
__attribute__((interrupt)) void isr4(interrupt_frame* frame) {print("overload");while(1);};
__attribute__((interrupt)) void isr5(interrupt_frame* frame) {print("table overload");while(1);};
__attribute__((interrupt)) void isr6(interrupt_frame* frame) {print("fake instruction");while(1);};
__attribute__((interrupt)) void isr7(interrupt_frame* frame) {print("FPU don't exist");while(1);};
__attribute__((interrupt)) void isr8(interrupt_frame* frame) {print("double fault");while(1);};
__attribute__((interrupt)) void isr9(interrupt_frame* frame) {print("unused");while(1);};



bool add_errors(){
	add_IRQ(0, isr0, IDT_TG);
	add_IRQ(1, isr1, IDT_TG);
	add_IRQ(2, isr2, IDT_TG);
	add_IRQ(3, isr3, IDT_TG);
	add_IRQ(4, isr4, IDT_TG);
	add_IRQ(5, isr5, IDT_TG);
	add_IRQ(6, isr6, IDT_TG);
	add_IRQ(7, isr7, IDT_TG);
	add_IRQ(8, isr8, IDT_TG);
	add_IRQ(9, isr9, IDT_TG);
	return 1;
}
