#define AND &&
#define OR ||
#define False false
#define True true
#define XOR !
#include "typedefs.h"
