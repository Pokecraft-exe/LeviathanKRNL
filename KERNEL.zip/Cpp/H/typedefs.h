#pragma once
#include <stdint.h>
typedef unsigned char uint8;
typedef unsigned short uint16;
typedef unsigned int uint32;
typedef unsigned long long uint64;
typedef signed char int8;
typedef signed short int16;
typedef signed int int32;
typedef signed long long int64;
typedef unsigned char uint_8;
typedef unsigned short uint_16;
typedef unsigned int uint_32;
typedef unsigned long long uint_64;
typedef signed char int_8;
typedef signed short int_16;
typedef signed int int_32;
typedef signed long long int_64;
typedef unsigned char byte;
typedef signed char sbyte;
typedef unsigned int dword;
typedef long unsigned int size_t;
typedef const char* string;
typedef const char* str;
typedef const char* String;
typedef const char* Str;
