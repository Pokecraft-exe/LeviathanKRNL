#pragma once
#ifndef errors
#define errors
#include "IDT.h"
#include "printf.h"

bool add_errors();
#endif
