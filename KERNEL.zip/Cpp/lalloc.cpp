#include "H/lalloc.h"

Chunk_List alloced = { 0 };
size_t free_chunks_count = 1;
uintptr_t heap[HEAP_CAPACITY / sizeof(uintptr_t)] = { 0 };

void chunk_invert(Chunk_List* list, size_t index1, size_t index2) {
	list->chunks[index1].start = (uintptr_t*)((size_t)list->chunks[index1].start ^ (size_t)list->chunks[index2].start);
	list->chunks[index2].start = (uintptr_t*)((size_t)list->chunks[index2].start ^ (size_t)list->chunks[index1].start);
	list->chunks[index1].start = (uintptr_t*)((size_t)list->chunks[index1].start ^ (size_t)list->chunks[index2].start);

	list->chunks[index1].size = list->chunks[index1].size ^ list->chunks[index2].size;
	list->chunks[index2].size = list->chunks[index2].size ^ list->chunks[index1].size;
	list->chunks[index1].size = list->chunks[index1].size ^ list->chunks[index2].size;
}

int chunk_insert(Chunk_List* list, uintptr_t* ptr, size_t size) {
	if (!(list->count < CHUNK_LIST_CAP)) return NULL;
	list->chunks[list->count].start = ptr;
	list->chunks[list->count].size = size;
	for (size_t i = list->count; i > 0 && list->chunks[i].start < list->chunks[i - 1].start; i--) {
		chunk_invert(list, i - 1, i);
	}
	list->count++;
	return 0;
}

void chunk_remove(Chunk_List* list, size_t index) {
	list->chunks[index].size = 0;
	list->chunks[index].start = NULL;
	for (size_t i = index; i < list->count; i++) {
		chunk_invert(list, i + 1, i);
	}
	list->count--;
}

Chunk get_free_chunk(const Chunk_List* list, size_t size) {
	size_t tsize = 0, i = 1;
	while (i <= list->count) {
		tsize += list->chunks[i - 1].size;
		if (list->chunks[i - 1].start + list->chunks[i - 1].size != list->chunks[i].start) {
			if ((heap + tsize) - list->chunks[i].start == size)
				return { heap + tsize, (size_t)((heap + tsize) - list->chunks[i].start) };
		}
		i++;
	}
	tsize += list->chunks[i - 1].size;
	return { heap + tsize, HEAP_CAPACITY - tsize };
}

void* alloc(size_t size) {
	if (size == 0) return NULL;
	Chunk t;
	t = get_free_chunk(&alloced, size);
	if (t.size >= size) {
		if (t.size == size) free_chunks_count--;
		chunk_insert(&alloced, t.start, size);
		return t.start;
	}
	return NULL;
}

void free(void* ptr) {
	if (ptr != NULL) {
		int index = alloced.Search(0, alloced.count, (uintptr_t*)ptr);
		if (index < 0) return;
		chunk_remove(&alloced, index);
		free_chunks_count++;
	}
}

void* realloc(void* ptr, size_t size) {
	free((uintptr_t*)ptr);
	return alloc(size);
}

size_t get_used() {
	size_t tsize = 0;
	for (size_t i = 0; i < alloced.count; i++) {
		tsize += alloced.chunks[i].size;
	}
	return tsize;
}
