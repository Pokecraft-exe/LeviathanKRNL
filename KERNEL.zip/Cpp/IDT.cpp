#include "H/IDT.h"

IDTR idtrr;
IDT64 IDTA[64];
char IDTAi;
  
void InitIDT(){
    idtrr.address = (uint64_t)IDTA;
    idtrr.size = sizeof(IDT64) * 64;
    
    asm ("lidt %0" :: "m"(idtrr));

    RemapPic(0,0);
    
    outb(0x21, 0b11111101);
    outb(0xA1, 0b11111111);
    
    asm ("sti");
}
  
void add_IRQ(char IRQ, void(*function)(interrupt_frame*), uint8_t gate) {
  	IRQ_clear_mask(IRQ);
	IDTA[IRQ].Set_Offset((uint64_t)function);
	IDTA[IRQ].types_attr = gate;
	IDTA[IRQ].selector = 0x8;
}

__attribute__((interrupt)) void isr1_handler(interrupt_frame* frame){
	write_serial('\n');
	uint_8 scanCode = inb(0x60);
	uint_8 chr = 0;

	if (scanCode < 0x3A){
		chr = ScanCodeLookupTable[scanCode];
	}
	Keyboardhandler(scanCode, chr);
	write_serial(KEY);
	outb(0x20, 0x20);
	outb(0xa0, 0x20);
}

int panic(CPUState state){
	print("Your computer will restart after pressing a key...");
	//write_serial('▄');write_serial('▄');write_serial('▄');write_serial('▄');write_serial('▄');write_serial('▄');write_serial('▄');write_serial(' ');write_serial(' ');write_serial('▄');write_serial(' ');write_serial(' ');write_serial(' ');write_serial(' ');write_serial(' ');write_serial('▄');write_serial('▄');write_serial(' ');write_serial(' ');write_serial('▄');write_serial(' ');write_serial(' ');write_serial('▄');write_serial('▄');write_serial('▄');write_serial('▄');write_serial('▄');write_serial('▄');write_serial('▄');write_serial('\n');write_serial('\r');write_serial('█');write_serial(' ');write_serial('▄');write_serial('▄');write_serial('▄');write_serial(' ');write_serial('█');write_serial(' ');write_serial('▀');write_serial('█');write_serial('▄');write_serial('█');write_serial('▀');write_serial(' ');write_serial('▄');write_serial(' ');write_serial('▄');write_serial('▀');write_serial('█');write_serial(' ');write_serial(' ');write_serial(' ');write_serial('█');write_serial(' ');write_serial('▄');write_serial('▄');write_serial('▄');write_serial(' ');write_serial('█');write_serial('\n');write_serial('\r');write_serial('█');write_serial(' ');write_serial('█');write_serial('█');write_serial('█');write_serial(' ');write_serial('█');write_serial(' ');write_serial('▀');write_serial('▀');write_serial('▄');write_serial('▀');write_serial('▄');write_serial('▄');write_serial('▄');write_serial('▄');write_serial(' ');write_serial(' ');write_serial(' ');write_serial('▄');write_serial('█');write_serial(' ');write_serial('█');write_serial(' ');write_serial('█');write_serial('█');write_serial('█');write_serial(' ');write_serial('█');write_serial('\n');write_serial('\r');write_serial('█');write_serial('▄');write_serial('▄');write_serial('▄');write_serial('▄');write_serial('▄');write_serial('█');write_serial(' ');write_serial('█');write_serial(' ');write_serial('█');write_serial(' ');write_serial('▄');write_serial('▀');write_serial('█');write_serial('▀');write_serial('█');write_serial(' ');write_serial('█');write_serial(' ');write_serial('▄');write_serial(' ');write_serial('█');write_serial('▄');write_serial('▄');write_serial('▄');write_serial('▄');write_serial('▄');write_serial('█');write_serial('\n');write_serial('\r');write_serial('▄');write_serial('▄');write_serial('▄');write_serial('▄');write_serial('▄');write_serial(' ');write_serial('▄');write_serial('▄');write_serial('▄');write_serial('▄');write_serial('▄');write_serial(' ');write_serial('█');write_serial('▀');write_serial('▄');write_serial('█');write_serial(' ');write_serial(' ');write_serial('▀');write_serial('▄');write_serial(' ');write_serial('▄');write_serial(' ');write_serial('▄');write_serial(' ');write_serial('▄');write_serial(' ');write_serial('▄');write_serial(' ');write_serial('\n');write_serial('\r');write_serial('█');write_serial('▄');write_serial('▀');write_serial(' ');write_serial(' ');write_serial('▀');write_serial('▄');write_serial('▀');write_serial('█');write_serial('█');write_serial(' ');write_serial('▄');write_serial('▄');write_serial(' ');write_serial(' ');write_serial('█');write_serial('▀');write_serial('▄');write_serial('▀');write_serial('▀');write_serial('█');write_serial('▄');write_serial('▀');write_serial('█');write_serial('█');write_serial(' ');write_serial(' ');write_serial(' ');write_serial('▀');write_serial('\n');write_serial('\r');write_serial('█');write_serial(' ');write_serial('▀');write_serial(' ');write_serial('▄');write_serial(' ');write_serial('▄');write_serial('█');write_serial('▄');write_serial('█');write_serial('▀');write_serial('█');write_serial(' ');write_serial(' ');write_serial('▀');write_serial('▄');write_serial('█');write_serial(' ');write_serial(' ');write_serial('▄');write_serial('▄');write_serial('▄');write_serial('▀');write_serial('▀');write_serial(' ');write_serial('█');write_serial('▄');write_serial('▀');write_serial(' ');write_serial('\n');write_serial('\r');write_serial('▀');write_serial(' ');write_serial(' ');write_serial('▄');write_serial(' ');write_serial('▀');write_serial('▄');write_serial(' ');write_serial(' ');write_serial('▀');write_serial('▀');write_serial(' ');write_serial('▀');write_serial('█');write_serial('█');write_serial('▄');write_serial(' ');write_serial('▄');write_serial('▀');write_serial(' ');write_serial('▀');write_serial('▀');write_serial('█');write_serial('▀');write_serial('▀');write_serial('▄');write_serial('▄');write_serial(' ');write_serial('▀');write_serial('\n');write_serial('\r');write_serial('▀');write_serial('▄');write_serial('█');write_serial('▀');write_serial(' ');write_serial('▀');write_serial('▄');write_serial('▀');write_serial('█');write_serial('▀');write_serial('█');write_serial(' ');write_serial('█');write_serial('▀');write_serial('▄');write_serial('█');write_serial('█');write_serial('▄');write_serial('█');write_serial('▄');write_serial('▀');write_serial('▀');write_serial('▀');write_serial('▄');write_serial('▀');write_serial('▄');write_serial('▄');write_serial('▀');write_serial(' ');write_serial('\n');write_serial('\r');write_serial('█');write_serial(' ');write_serial('█');write_serial('▄');write_serial('█');write_serial('▄');write_serial('▄');write_serial('▀');write_serial('▀');write_serial('▀');write_serial(' ');write_serial('▄');write_serial('▄');write_serial(' ');write_serial(' ');write_serial('█');write_serial('▀');write_serial(' ');write_serial(' ');write_serial(' ');write_serial('█');write_serial('▀');write_serial('▀');write_serial('█');write_serial('▀');write_serial(' ');write_serial('█');write_serial(' ');write_serial('▀');write_serial('\n');write_serial('\r');write_serial('█');write_serial(' ');write_serial(' ');write_serial('█');write_serial(' ');write_serial('▀');write_serial('▄');write_serial('▀');write_serial('█');write_serial('█');write_serial('▄');write_serial('█');write_serial(' ');write_serial(' ');write_serial('▀');write_serial('▄');write_serial('█');write_serial('▄');write_serial(' ');write_serial('█');write_serial('█');write_serial('▄');write_serial('█');write_serial('█');write_serial('▄');write_serial(' ');write_serial('▄');write_serial('█');write_serial('▄');write_serial('\n');write_serial('\r');write_serial('▄');write_serial('▄');write_serial('▄');write_serial('▄');write_serial('▄');write_serial('▄');write_serial('▄');write_serial(' ');write_serial('█');write_serial(' ');write_serial('█');write_serial(' ');write_serial('▀');write_serial('█');write_serial('█');write_serial('▄');write_serial('█');write_serial('█');write_serial('▀');write_serial('▄');write_serial('█');write_serial(' ');write_serial('▄');write_serial(' ');write_serial('█');write_serial('█');write_serial('█');write_serial('▀');write_serial('▀');write_serial('\n');write_serial('\r');write_serial('█');write_serial(' ');write_serial('▄');write_serial('▄');write_serial('▄');write_serial(' ');write_serial('█');write_serial(' ');write_serial('▄');write_serial(' ');write_serial('▀');write_serial(' ');write_serial('█');write_serial('▀');write_serial('▄');write_serial('▄');write_serial('▄');write_serial('▄');write_serial('▀');write_serial(' ');write_serial('█');write_serial('▄');write_serial('▄');write_serial('▄');write_serial('█');write_serial(' ');write_serial('▄');write_serial('▄');write_serial('▀');write_serial('\n');write_serial('\r');write_serial('█');write_serial(' ');write_serial('█');write_serial('█');write_serial('█');write_serial(' ');write_serial('█');write_serial(' ');write_serial('█');write_serial('▄');write_serial('█');write_serial('▄');write_serial('▄');write_serial(' ');write_serial(' ');write_serial('▄');write_serial('▀');write_serial('▀');write_serial('▄');write_serial('█');write_serial(' ');write_serial('▄');write_serial('▄');write_serial('▄');write_serial('▄');write_serial('█');write_serial('█');write_serial('█');write_serial('▀');write_serial('\n');write_serial('\r');write_serial('█');write_serial('▄');write_serial('▄');write_serial('▄');write_serial('▄');write_serial('▄');write_serial('█');write_serial(' ');write_serial('█');write_serial('▄');write_serial(' ');write_serial('█');write_serial(' ');write_serial(' ');write_serial('▀');write_serial('█');write_serial('█');write_serial(' ');write_serial('▀');write_serial('▄');write_serial('▀');write_serial('▄');write_serial('▀');write_serial('▄');write_serial('▄');write_serial('▀');write_serial('▄');write_serial('▀');write_serial(' ');write_serial('\n');write_serial('\r');
	while(read_serial() == '\0')continue;
	restart();
	return 0;
}

__attribute__((interrupt)) void pagefault(struct interrupt_frame* frame){
	write_serial('\033');
	write_serial('[');
	write_serial('1');
	write_serial(';');
	write_serial('3');
	write_serial('1');
	write_serial('m');
	write_serial('p');
	write_serial('a');
	write_serial('g');
	write_serial('e');
	write_serial(' ');
	write_serial('f');
	write_serial('a');
	write_serial('u');
	write_serial('l');
	write_serial('t');
	write_serial('!');
	write_serial('\n');
	write_serial('\r');
	//panic(GetState());
	while(true);
}
