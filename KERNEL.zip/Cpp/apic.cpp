bool check_apic() {
	bool support;
	asm("mov %eax, 1");
	asm("cpuid");
	asm volatile ("mov %%edx[9], %[VAR]" : [VAR] "=r" (support));
	return support;
}
